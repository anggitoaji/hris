from datetime import date, datetime

from sqlalchemy import Boolean, Date, DateTime, Float, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Employee(Base):
    """Tabel karyawan.

    Field status / contract_type / ai_risk disimpan sebagai string biasa
    (validasi nilai dilakukan di layer Pydantic schema). Ini lebih sederhana
    dan aman untuk SQLite maupun PostgreSQL dibanding native ENUM.
    """

    __tablename__ = "employees"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    nik: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    nama: Mapped[str] = mapped_column(String(128), index=True)
    email: Mapped[str | None] = mapped_column(String(128), unique=True, nullable=True)
    phone: Mapped[str | None] = mapped_column(String(32), nullable=True)

    department: Mapped[str] = mapped_column(String(64), index=True)  # divisi
    position: Mapped[str] = mapped_column(String(64))                # jabatan

    status: Mapped[str] = mapped_column(String(16), default="Aktif", index=True)
    contract_type: Mapped[str] = mapped_column(String(16), default="Kontrak")
    join_date: Mapped[date | None] = mapped_column(Date, nullable=True)

    kpi_score: Mapped[float] = mapped_column(Float, default=0.0)
    ai_risk: Mapped[str] = mapped_column(String(8), default="Low")

    photo_url: Mapped[str | None] = mapped_column(String(256), nullable=True)

    # Soft delete: data tidak dihapus permanen, hanya ditandai non-aktif.
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )
