from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Konfigurasi aplikasi, dibaca dari environment / file .env."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    APP_NAME: str = "Solusi Group HRIS API"
    APP_VERSION: str = "0.1.0"
    API_PREFIX: str = "/api"

    # Default: SQLite (langsung jalan di laptop, tanpa install PostgreSQL).
    # Untuk produksi, ganti jadi:
    # postgresql+psycopg://user:password@localhost:5432/hris
    DATABASE_URL: str = "sqlite:///./hris.db"

    # Origin frontend yang diizinkan (pisah dengan koma untuk banyak origin).
    CORS_ORIGINS: str = "http://localhost:3000"

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


settings = Settings()
