from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import employees
from app.core.config import settings
from app.core.database import Base, engine

# Import model agar terdaftar di metadata sebelum create_all.
from app.models import employee as _employee_model  # noqa: F401


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Buat tabel otomatis saat startup (cukup untuk MVP / development).
    # Untuk produksi, sebaiknya pakai migration (Alembic).
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(employees.router, prefix=settings.API_PREFIX)


@app.get("/health", tags=["System"])
def health():
    return {"status": "ok", "app": settings.APP_NAME, "version": settings.APP_VERSION}
